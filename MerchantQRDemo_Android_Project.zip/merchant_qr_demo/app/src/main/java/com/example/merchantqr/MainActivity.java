package com.example.merchantqr;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.widget.*;
import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    EditText shop, upi, amount;
    ImageView qr;
    TextView preview, payload;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        shop=findViewById(R.id.shopName);
        upi=findViewById(R.id.upiId);
        amount=findViewById(R.id.amount);
        qr=findViewById(R.id.qr);
        preview=findViewById(R.id.namePreview);
        payload=findViewById(R.id.payload);

        findViewById(R.id.generate).setOnClickListener(v -> generate());
    }

    void generate() {
        String name=shop.getText().toString().trim();
        String id=upi.getText().toString().trim();
        String amt=amount.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            name = "Demo Merchant";
            shop.setText(name);
        }
        if (!id.matches("^[A-Za-z0-9._-]{2,256}@[A-Za-z0-9.-]{2,64}$")) {
            upi.setError("Enter a valid UPI ID");
            return;
        }

        try {
            StringBuilder s=new StringBuilder("upi://pay?pa=");
            s.append(URLEncoder.encode(id, "UTF-8"));
            s.append("&pn=").append(URLEncoder.encode(name, "UTF-8"));
            if (!amt.isEmpty()) {
                double a=Double.parseDouble(amt);
                if (a < 0) throw new Exception();
                s.append("&am=").append(URLEncoder.encode(String.format(java.util.Locale.US,"%.2f",a),"UTF-8"));
            }
            s.append("&cu=INR");
            String data=s.toString();

            BarcodeEncoder enc=new BarcodeEncoder();
            Bitmap bmp=enc.encodeBitmap(data, BarcodeFormat.QR_CODE, 900, 900);
            qr.setImageBitmap(bmp);
            preview.setText("Merchant name: "+name);
            payload.setText("UPI payload:\n"+data);
        } catch(Exception e) {
            Toast.makeText(this,"Could not generate QR",Toast.LENGTH_SHORT).show();
        }
    }
}
