# Merchant QR Demo — Android

Features:
- Enter your authorized UPI ID
- Enter shop/merchant name
- Optional amount
- Generate a QR locally using a standard UPI deep-link payload
- No real payment processing or Paytm integration

Open in Android Studio and build/install the debug APK.
The APK is normally produced at:
app/build/outputs/apk/debug/app-debug.apk
